/**
* @author Alexander Stahl, Sebastian Voigt
*The interface layer of hotkeyapp.
*/
package de.beuth.s66821.hotkeyapp.rest_interface;