/**
*@author Alexander Stahl, Sebastian
*Contains implementations for services required by other parts of the application.
*/
package de.beuth.s66821.hotkeyapp.infrastructure;