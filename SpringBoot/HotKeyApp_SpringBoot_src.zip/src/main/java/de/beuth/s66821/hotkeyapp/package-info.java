/**
 * @author Alexander Stahl, Sebastian Voigt
 * A sample project following Domain Driven Design with Spring Data JPA for SE2.
 * Project name hotkeyapp.
 */
package de.beuth.s66821.hotkeyapp;
