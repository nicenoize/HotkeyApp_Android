/**
 * @author Alexander Stahl, Sebastian Voigt
 * Contains interfaces for services required by the domain model of hotkeyapp.
 * 
 */
package de.beuth.s66821.hotkeyapp.domain.imports;