/**
 * @author Alexander Stahl, Sebastian Voigt
 * The domain model of hotkeyapp.
 * 
 */
package de.beuth.s66821.hotkeyapp.domain;