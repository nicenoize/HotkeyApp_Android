/**
 * HotKeyApp_GUI v0.5
 * #############################
 * @author Alexander Stahl
 * @version 0.5
 * #############################
 * This Application executes remote commands from the compianion Android-Application. This Application and the
 * Android-Application form the main parts of the system.
 */
package HotKeyApp;