/**
 * HotKeyApp_GUI v0.5
 * #############################
 * @author Alexander Stahl
 * @version 0.5
 * #############################
 * All GUI implemented Images are live in this package.
 */
package HotKeyApp.images;