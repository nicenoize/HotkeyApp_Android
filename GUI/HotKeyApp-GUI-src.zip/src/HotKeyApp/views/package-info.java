/**
 * HotKeyApp_GUI v0.5
 * #############################
 * @author Alexander Stahl
 * @version 0.5
 * #############################
 * JavaFXML-Files to style the GUI in a visual way (SceneBuilder).
 */
package HotKeyApp.views;