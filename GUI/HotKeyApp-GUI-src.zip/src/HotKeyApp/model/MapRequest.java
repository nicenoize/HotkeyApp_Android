package HotKeyApp.model;
/**
 * HotKeyApp_GUI v0.5
 * #############################
 * @author Alexander Stahl
 * @version 0.5
 * #############################
 * This class is needed by HotkeyServerListener. Sending an instance of this class to get a map from this program.
 */
public class MapRequest {}