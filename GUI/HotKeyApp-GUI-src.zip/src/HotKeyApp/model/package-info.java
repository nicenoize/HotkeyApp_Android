/**
 * HotKeyApp_GUI v0.5
 * #############################
 * @author Alexander Stahl
 * @version 0.5
 * #############################
 * Implements all logic aspects off the GUI-Application.
 */
package HotKeyApp.model;