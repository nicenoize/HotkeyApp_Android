/**
 * HotKeyApp_GUI v0.5
 * #############################
 * @author Alexander Stahl
 * @version 0.5
 * #############################
 * This package provides all functional aspects of the graphical user interface. Their are rudimental implementations for
 * parsing/writing JSON-Files. Only graphical stuff.
 */
package HotKeyApp.controller;