package com.example.android.hotkey_app;

import android.os.AsyncTask;
import android.view.View;
import android.widget.TextView;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryonet.Client;
import kryonet.packages.request.PingRequest;
import kryonet.packages.request.MapRequest;
import kryonet.packages.response.PingResponse;
import kryonet.packages.response.MapResponse;
import java.io.IOException;
import java.net.InetAddress;

public class ClientMain extends AsyncTask<Void, Void, Void>{

    @Override
    protected Void doInBackground(Void... voids) {
// ClientMain erstellen und starten
        Client client = new Client();
        client.start();
        System.out.println("[Client] Client gestarted");

        // Schaue im Netzwerk nach Servern und Verbinde dich (verbindet sich automatisch zum ersten der gefunden wird)
        InetAddress address = client.discoverHost(54777, 5000);
        //address = "141.64.172.144";
        // Listener für die packages anmelden
        client.addListener(new ClientListener());

        // Pakete (packages) anmelden
        Kryo kryo = client.getKryo();
        kryo.register(PingRequest.class);
        kryo.register(MapRequest.class);
        kryo.register(PingResponse.class);
        kryo.register(MapResponse.class);


        // Client an Ports binden
        try {
            //client.connect(5000, address, 9999, 54777);
            client.connect(5000,"192.168.31.79", 9999,54777);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // ALT (PING REQUEST)
        // Client sendet Request
        PingRequest pingRequest = new PingRequest();
        client.sendTCP(pingRequest);

        // NEU (MAP REQUEST)
        MapRequest mapRequest = new MapRequest();
        client.sendTCP(mapRequest);

        // Damit sich das Prog nicht beendet und auf die Nachricht vom Server wartet
        while(true){}
    }
}
