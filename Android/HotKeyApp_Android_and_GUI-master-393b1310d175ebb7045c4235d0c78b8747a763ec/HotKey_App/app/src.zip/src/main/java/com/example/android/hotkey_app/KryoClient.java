package com.example.android.hotkey_app;

import android.os.AsyncTask;
import android.view.View;
import android.widget.TextView;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryonet.Client;
import kryonet.packages.request.PingRequest;
import kryonet.packages.request.MapRequest;
import kryonet.packages.response.PingResponse;
import kryonet.packages.response.MapResponse;
import java.io.IOException;
import java.net.InetAddress;

/**
 * Created by poorboy on 12.12.17.
 */
public class KryoClient {
    final int TIMEOUT = 5000;

    public KryoClient() {
        // ClientMain erstellen und starten
        Client client = new Client();
        client.start();

        // Schaue im Netzwerk nach Servern und Verbinde dich (verbindet sich automatisch zum ersten der gefunden wird)
        InetAddress address = client.discoverHost(54777, TIMEOUT);
        //address = "141.64.172.144";

        // Listener für die packages anmelden
        client.addListener(new ClientListener());

        // Pakete (packages) anmelden
        Kryo kryo = client.getKryo();
        kryo.register(PingRequest.class);
        kryo.register(MapRequest.class);
        kryo.register(PingResponse.class);
        kryo.register(MapResponse.class);

        // Client an Ports binden
        try {
            //client.connect(5000, address, 9999, 54777);
            client.connect(5000,"127.0.0.1", 9999,54777);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // ALT (PING)
        // Client sendet Request
        PingRequest pingRequest = new PingRequest();
        client.sendTCP(pingRequest);

        // NEU (MAP REQUEST)
        MapRequest mapRequest = new MapRequest();
        client.sendTCP(mapRequest);

        // Damit sich das Prog nicht beendet und auf die Nachricht vom Server wartet
        while(true){ }
    }
}