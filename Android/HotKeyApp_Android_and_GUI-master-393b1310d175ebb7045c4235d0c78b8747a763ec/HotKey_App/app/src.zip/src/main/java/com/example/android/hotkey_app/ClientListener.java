package com.example.android.hotkey_app;

import com.esotericsoftware.kryonet.Connection;
import com.esotericsoftware.kryonet.Listener;
import kryonet.packages.response.PingResponse;
import kryonet.packages.response.MapResponse;


public class ClientListener extends Listener {

    @Override
    public void connected(Connection connection){
        System.out.println("[Client] Verbunden!");
    }

    @Override
    public void disconnected(Connection connection){
        System.out.println("[Client] Verbindung getrennt!");
    }

    @Override
    public void received(Connection connection, Object object){

        if (object instanceof PingResponse){
            PingResponse pingResponse = (PingResponse) object;

            System.out.println("Nachricht: " + pingResponse.text);
            System.out.println("Zeit: " + pingResponse.time);
        }
        else if (object instanceof MapResponse){
            MapResponse mapResponse = (MapResponse) object;

            // So den Identifier auslesen
            System.out.println("Identifier: " + mapResponse.identifier);

            // Command ist dann eigentlich Hotkey, kein String, dem Button dann sagen, dass
            // der text des buttons = mapResponse.identifer und wenn er gedrückt wird, soll er
            // new PingRequest() machen, dann sollte Hello World auf deinem PC kommen
            System.out.println("Command: " + mapResponse.command);
            // Hier ist die Map angekommen, loadingscreen kann weg, und buttons können augebaut werden.
        }

    }
}
