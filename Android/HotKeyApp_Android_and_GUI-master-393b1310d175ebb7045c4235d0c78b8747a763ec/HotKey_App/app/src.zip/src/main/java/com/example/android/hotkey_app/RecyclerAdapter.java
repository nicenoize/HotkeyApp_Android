package com.example.android.hotkey_app;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.esotericsoftware.kryonet.Client;
import java.util.ArrayList;
import java.util.List;
import kryonet.client.KryoClient;

import kryonet.packages.request.MapRequest;
import kryonet.packages.request.PingRequest;
import kryonet.packages.response.MapResponse;
import kryonet.packages.response.PingResponse;

/**
 * Created by work on 12.12.17.
 */

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewholder>{

    private List<MapResponse> list = new ArrayList<>();

    RecyclerAdapter(List<MapResponse> list) {
        this.list = list;
    }

    @Override
    public MyViewholder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_view, parent, false);

        return new MyViewholder(view);
    }

    @Override
    public void onBindViewHolder(MyViewholder holder, int position) {
        holder.Id.setText(list.get(position).getIdentifier());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class MyViewholder extends RecyclerView.ViewHolder{
        Button Id;

        public MyViewholder(View itemView) {
            super(itemView);
            Id = (Button)itemView.findViewById(R.id.identifier);
            Id.setOnClickListener(new View.OnClickListener(){
                public void onClick(View view){
                Client client = new Client();
                client.sendTCP()
                }
            });
        }

    }
}
