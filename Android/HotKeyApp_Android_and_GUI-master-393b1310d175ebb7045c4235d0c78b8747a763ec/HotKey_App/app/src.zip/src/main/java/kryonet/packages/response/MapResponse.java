package kryonet.packages.response;

/**
 * Created by poorboy on 12.12.17.
 */
public class MapResponse {
    public String identifier = "Hello World";
    public String command = "hmm";              // Das hier wäre dann ein Hotkey und kein String

    public String getIdentifier() {
        return identifier;
    }

    public String getCommand() {
        return command;
    }
}
