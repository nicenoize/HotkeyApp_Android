package kryonet.packages.response;

import java.util.Date;

/**
 * Created by poorboy on 30.11.17.
 */
public class PingResponse {

    public long time = System.currentTimeMillis();
    public String text = "Es fnktioniert! YEAH!!";
}