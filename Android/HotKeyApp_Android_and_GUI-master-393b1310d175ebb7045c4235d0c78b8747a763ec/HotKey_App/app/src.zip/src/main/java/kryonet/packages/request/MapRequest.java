package kryonet.packages.request;

/**
 * Created by poorboy on 12.12.17.
 */
public class MapRequest {
}
