package kryonet.packages.request;

/**
 * Created by poorboy on 30.11.17.
 */
public class PingRequest {
}
