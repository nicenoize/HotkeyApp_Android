package communicationObjects;

/**
 * Created by poorboy on 12.12.17.
 */

// Der Client schickt dem Server dass er eine Map haben möchte
public class MapRequest {
}
